package classesEDCV;

import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;

public class WEG {
	
	private ArrayList<ServicoManutencao> listaServicoManutencao = new ArrayList<ServicoManutencao>();
	private ArrayList<ProdutoWEG> listaProdutoWEG = new ArrayList< ProdutoWEG >();
	
	public static void main ( String [] args ) {
		
		WEG weg = new WEG ();
		String [] escolhas = { "Inversor de frequência" , "Motor elétrico" , "Gerador" , "Outro produto" , "Cadastrar um serviço de manutenção" , "Ver produtos cadastrados" , "Ver os serviços de um produto" };
		String escolha  = ( String ) JOptionPane.showInputDialog
		( null , null , null , JOptionPane.INFORMATION_MESSAGE, null, escolhas , escolhas [3] );;
		while ( escolha != null ) {
			
			switch ( escolha ) {
			case "Inversor de frequência" : {
				InversorFrequencia inversor = InversorFrequenciaCadastro.CadastroProduto();
				if ( inversor != null ) {
					weg.addProdutoWEG ( inversor );
				}
			} break;
			case "Motor elétrico" : {
				MotorEletrico motor = MotorEletricoCadastro.CadastroProduto();
				if ( motor != null  ) {
					weg.addProdutoWEG ( motor );
				}
			} break;
			case "Gerador" : {
				Gerador gerador = GeradorCadastro.CadastroProduto();
				if ( gerador != null  ) {
					weg.addProdutoWEG ( gerador );
				}
			} break;
			case "Outro produto" : {
				ProdutoWEG produto = ProdutoWEGcadastro.CadastroProduto();
				if ( produto != null  ) {
					weg.addProdutoWEG ( produto );
				}
			} break;
			case "Cadastrar um serviço de manutenção" : {
				ServicoManutencao servico = ServicoManuntencaoCadastro.CadastroServico();
				if ( servico != null  ) {
					weg.addManutencao ( servico );
				}
			
			} break;
			
			case "Ver produtos cadastrados" : {
				weg.verProdutosCadastrados();
			} break;
			
			case "Ver os serviços de um produto" : {
				weg.verServicosProduto();
			} break;
			
			}
			escolha = ( String ) JOptionPane.showInputDialog
			( null , null , null , JOptionPane.INFORMATION_MESSAGE, null, escolhas , escolhas [3] );
			
		}
		
	}
	
	public void addProdutoWEG ( ProdutoWEG produto ) {
		listaProdutoWEG.add( produto );
			
	}
	
	public void addManutencao ( ServicoManutencao servico ) {
		listaServicoManutencao.add( servico );
			
	}
	
	public void removeProdutoWEG ( ProdutoWEG produto ) {
		listaProdutoWEG.remove ( produto );
	}
	
	public void verProdutosCadastrados () {
		
		String produtos [] = new String [ listaProdutoWEG.size() ] ;
		
		for ( int i = 0; i < listaProdutoWEG.size() ; i++ ) {	
			
			
			if ( listaProdutoWEG.get(i) instanceof InversorFrequencia ) {
				produtos [ i ] = "Nome: " + listaProdutoWEG.get(i).getNome() + "    Preço: R$" + String.format( "%.2f" , listaProdutoWEG.get(i).getPreco()) + 
						"    Número de fases: " + (( InversorFrequencia ) listaProdutoWEG.get(i)).getNumeroFases();
					
			} else if ( listaProdutoWEG.get(i) instanceof MotorEletrico ){
				produtos [ i ] = "Nome: " + listaProdutoWEG.get(i).getNome() + "    Preço: R$" + String.format( "%.2f" ,  listaProdutoWEG.get(i).getPreco()) + 
						"    Tipo de enrolamento: " + (( MotorEletrico ) listaProdutoWEG.get(i)).getTipoEnrolamento();
				
			} else if ( listaProdutoWEG.get(i) instanceof Gerador ){
				produtos [ i ] = "Nome: " + listaProdutoWEG.get(i).getNome() + "    Preço: R$" + String.format( "%.2f" , listaProdutoWEG.get(i).getPreco()) + 
						"    Horas de autonomia: " + (( Gerador ) listaProdutoWEG.get(i)).getAutonomia();
				
			} else {
				produtos [ i ] = "Nome: " + listaProdutoWEG.get(i).getNome() + "    Preço: R$" + String.format( "%.2f" , listaProdutoWEG.get(i).getPreco());
			}
		}		
		
		String manutencao [] = new String [ listaServicoManutencao.size() ] ;
		
		for ( int i = 0; i < listaServicoManutencao.size() ; i++ ) {
			manutencao [ i ] = "Descrição: " + listaServicoManutencao.get(i).getDescricao() +"    " + "Custo: " + listaServicoManutencao.get(i).getCusto();
		}	
		
		JList<String> listProdutos = new JList<String> ( produtos );
		JList<String> listManutencoes = new JList<String> ( manutencao );
		
		JLabel 	produtosW = new JLabel( "Produtos: " ), 
				servicosManutencao = new JLabel ( "Serviços de Manutenção: " );
		
		Object componentes [] = { produtosW , listProdutos , servicosManutencao , listManutencoes };
		JOptionPane.showMessageDialog( null , componentes);
		
		}
	
public void verServicosProduto () {
		
		String produtos [] = new String [ listaProdutoWEG.size() ] ;
		
		if ( !listaProdutoWEG.isEmpty() ) {
			
		for ( int i = 0; i < listaProdutoWEG.size() ; i++ ) {	
			produtos [ i ] = "Cód." + String.format("%05d", i ) + "    Nome: " + listaProdutoWEG.get(i).getNome() + "    Tipo: " + listaProdutoWEG.get(i).getTipo() ;
			}		
			
		String escolha = ( String ) JOptionPane.showInputDialog
				( null , null , null , JOptionPane.INFORMATION_MESSAGE, null, produtos , produtos [0] );
				
		
		} else {
			JOptionPane.showMessageDialog ( null, "NÃO HÁ PRODUTOS CADASTRADOS!" );
		}
			
			
			
				
			 
		} 
	
	public ProdutoWEG getListaProdutoWEG( int i ) {
		
		if ( listaProdutoWEG.get (i).getClass() .getName().equals("MotorEletrico")) {
			return ( MotorEletrico ) listaProdutoWEG.get(i);
			
		} else if ( listaProdutoWEG.get (i).getClass() .getName().equals("InversorFrequencia")) {
			return ( InversorFrequencia ) listaProdutoWEG.get(i);
			
		} else if ( listaProdutoWEG.get (i).getClass() .getName().equals("ProdutoWEG")) {
			return listaProdutoWEG.get(i);
			
		}
		
		return null;
	}

}
