package classesEDCV;

public class MotorEletrico extends ProdutoWEG {

	private String tipoEnrolamento;
	private float eficiencia;
	
	/**
	 * metodo construtor contendo todos atributos da classe pai e mais os proprios
	 * @param codigo
	 * @param tipo
	 * @param potencia
	 * @param tensao
	 * @param capacidade
	 * @param preco
	 */
	public MotorEletrico ( String nome , Object tipo , float potencia , float tensao , float preco , String tipoEnrolamento , float eficiencia ) {
		super ( nome , tipo , potencia , tensao , preco );
		setEficiencia ( eficiencia );
		setTipoEnrolamento ( tipoEnrolamento );
		
	}
	
	/**
	 * Constructor vazio
	 */
	public MotorEletrico () {
		
	}
	
	
	/**
	 * setter do atributo eficiencia
	 * @param eficiencia
	 */
	public void setEficiencia ( float eficiencia ) {
		this.eficiencia = eficiencia;
	}
	
	/**
	 * getter do atributo eficiencia
	 * @return valor de eficiencia
	 */
	public float getEficiencia () {
		return eficiencia;
	}
	
	
	/**
	 * setter do atributo tipoEnrolamento
	 * @param tipoEnrolamento
	 */
	public void setTipoEnrolamento ( String tipoEnrolamento ) {
		this.tipoEnrolamento = tipoEnrolamento;
	}
	
	/**
	 * getter do atributo tipoEnrolamento
	 * @return valor de tipoEnrolamento
	 */
	public String getTipoEnrolamento () {
		return tipoEnrolamento;
	}

}
