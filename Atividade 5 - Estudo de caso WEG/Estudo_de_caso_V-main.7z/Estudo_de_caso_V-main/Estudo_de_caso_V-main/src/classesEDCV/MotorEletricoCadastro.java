package classesEDCV;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class MotorEletricoCadastro {
	public static MotorEletrico CadastroProduto ( ) {	
		JLabel 	nome = new JLabel ( "Insira o nome: " ) , 
				preco = new JLabel( "Insira o preço do produto: " ),
				potencia = new JLabel ( "Insira a potência: " ),
				tensao = new JLabel ( "Insira a tensão (V): " ),
				tipoEnrolamento = new JLabel ( "Insira o tipo de enrolamento: " ),
				eficiencia = new JLabel ( "Insira a eficiência do motor: " );
		
		JTextField 	tfNome = new JTextField (), 
					tfPreco = new JTextField () , 
					tfPotencia = new JTextField() , 
					tfTipoEnrolamento = new JTextField(),
					tfEficiencia = new JTextField();
		
		Object juntador [] = 
			{ nome , tfNome , preco , tfPreco , potencia , tfPotencia , tipoEnrolamento, 
				tfTipoEnrolamento, eficiencia, tfEficiencia , tensao };
		
		String teste = "";
		
		while ( teste != null && ( tfNome.getText().isBlank() || !tfPreco.getText().matches( "^[0-9]+$" ) || 
				!tfPotencia.getText().matches( "^[0-9]+$" ) || !teste.matches( "^[0-9]+$" ) || 
				tfTipoEnrolamento.getText().isBlank() || !tfEficiencia.getText().matches( "^[0-9]+$" ) ) ) {
			
			teste = ( String ) JOptionPane.showInputDialog
			( null , juntador , null );
			System.out.println ( teste );
		}

		if ( teste == null ) {
			return null;
		}
		
		
		MotorEletrico produto = new MotorEletrico ( 
				tfNome.getText() , 
				(Object)"Motor Elétrico",
				Float.parseFloat( tfPotencia.getText() ), 
				Float.parseFloat( teste ),
				Float.parseFloat( tfPreco.getText() ) , 
				tfTipoEnrolamento.getText(),
				Float.parseFloat( tfEficiencia.getText() )
				);
		
		return produto;
	}
}
