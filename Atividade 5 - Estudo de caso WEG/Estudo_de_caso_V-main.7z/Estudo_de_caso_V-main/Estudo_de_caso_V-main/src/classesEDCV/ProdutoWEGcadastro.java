package classesEDCV;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class ProdutoWEGcadastro {

	public static ProdutoWEG CadastroProduto ( ) {
		
		JLabel 	nome = new JLabel ( "Insira o nome: " ) , 
				preco = new JLabel( "Insira o preço do produto: " ),
				potencia = new JLabel ( "Insira a potência: " ),
				tensao = new JLabel ( "Insira a tensão (V): " );
		
		JTextField 	tfNome = new JTextField (), 
					tfPreco = new JTextField () , 
					tfPotencia = new JTextField() ; 
		
		Object juntador [] = 
			{ nome , tfNome , preco , tfPreco , potencia , tfPotencia , tensao };
		
		String teste = "";
		
		while ( teste != null && ( tfNome.getText().isBlank() || !tfPreco.getText().matches( "^[0-9]+$" ) || 
				!tfPotencia.getText().matches( "^[0-9]+$" ) || !teste.matches( "^[0-9]+$" ) ) ) {
			teste = ( String ) JOptionPane.showInputDialog
			( null , juntador , null );
			System.out.println ( teste );
		}

		if ( teste == null ) {
			return null;
		}
		
		ProdutoWEG produto = new ProdutoWEG ( 
				tfNome.getText() , 
				"Produto",
				Float.parseFloat( tfPreco.getText() ) , 
				Float.parseFloat( tfPotencia.getText() ), 
				Float.parseFloat( teste ) );
		
		return produto;
	}

}
