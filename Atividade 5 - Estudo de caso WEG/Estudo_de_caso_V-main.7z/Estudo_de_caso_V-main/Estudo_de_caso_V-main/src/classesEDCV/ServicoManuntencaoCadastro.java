package classesEDCV;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class ServicoManuntencaoCadastro {
	public static ServicoManutencao CadastroServico() {
		
		JLabel 	descricao = new JLabel ( "Insira a descrição da manutenção: " ) , 
				custo = new JLabel( "Insira o custo: " );
				
		JTextField  tfDescricao = new JTextField ();
		
		Object juntador [] = 
			{ descricao , tfDescricao , custo };
		
		String teste = "";
		
		while ( teste != null && ( tfDescricao.getText().isBlank() || !teste.matches( "^[0-9]+$" ) ) ) {
			teste = ( String ) JOptionPane.showInputDialog
			( null , juntador , null );
			System.out.println ( teste );
		}

		if ( teste == null ) {
			return null;
		}
		
		ServicoManutencao servico = new ServicoManutencao ( 
				tfDescricao.getText() , 
				Float.parseFloat( teste ) );
		
		return servico;
	}
}
